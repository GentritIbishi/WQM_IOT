package com.gentritibishi;

import org.apache.kafka.clients.producer.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Properties;

public class SensorDataApiProducer {
    public static void main(String[] args) {
        Properties props = new Properties();

        // Kafka settings for optimizing producer performance
        props.put("bootstrap.servers", "localhost:9092");
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

        // Optimization: Enable batching to reduce network overhead
        props.put("batch.size", 16384); // Batch up to 16 KB of messages
        props.put("linger.ms", 10); // Wait 10ms before sending the batch to allow more messages to accumulate

        // Optimization: Use gzip compression to reduce message size
        props.put("compression.type", "gzip");

        // Enable asynchronous sending to avoid blocking
        String apiUrl = "http://localhost:8080/api/sensors/generateData"; // URL to the API endpoint
        try (Producer<String, String> producer = new KafkaProducer<>(props)) {
            URL url = new URL(apiUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        String key = "SensorKey";
                        long sendTime = System.currentTimeMillis();
                        String recordData = line + String.format(",\"sendTime\":%d", sendTime);

                        // Send the message asynchronously
                        ProducerRecord<String, String> record = new ProducerRecord<>("SensorTopic", key, recordData);
                        producer.send(record, new Callback() {
                            @Override
                            public void onCompletion(RecordMetadata recordMetadata, Exception e) {
                                if (e != null) {
                                    e.printStackTrace();
                                } else {
                                    System.out.println("Message sent, offset: " + recordMetadata.offset());
                                }
                            }
                        });
                    }
                }
            } else {
                System.out.println("Failed to fetch data: HTTP error code " + conn.getResponseCode());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("Operation completed successfully");
    }
}
