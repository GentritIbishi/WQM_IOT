package com.gentritibishi;

import org.apache.kafka.clients.producer.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class SensorDataProducer {
    public static void main(String[] args) {
        Properties props = new Properties();

        // Kafka settings for optimizing producer performance
        props.put("bootstrap.servers", "localhost:9092");
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

        // Optimization: Enable batching to reduce network overhead
        props.put("batch.size", 16384); // Batch up to 16 KB of messages
        props.put("linger.ms", 10); // Wait 10ms before sending the batch to allow more messages to accumulate

        // Optimization: Use gzip compression to reduce message size
        props.put("compression.type", "gzip");

        // Enable asynchronous sending to avoid blocking
        String filePath = "/Users/gentritibishi/Documents/IOT/Project/DockerWaterQualityMonitoring/sensor_data.txt"; // Path to the input file
        try (Producer<String, String> producer = new KafkaProducer<>(props);
             BufferedReader reader = new BufferedReader(new FileReader(filePath))) {

            String line;
            StringBuilder jsonBuilder = new StringBuilder();
            while ((line = reader.readLine()) != null) {
                if (line.isEmpty()) {
                    // If an empty line is found, send the accumulated data as a message
                    if (jsonBuilder.length() > 0) {
                        String key = "SensorKey";

                        // Capture sendTime to be included in the Kafka message
                        long sendTime = System.currentTimeMillis();
                        String recordData = jsonBuilder.toString() + String.format("\"sendTime\":%d", sendTime);

                        // Send the message asynchronously
                        ProducerRecord<String, String> record = new ProducerRecord<>("SensorTopic", key, recordData);
                        producer.send(record, new Callback() {
                            @Override
                            public void onCompletion(RecordMetadata recordMetadata, Exception e) {
                                if (e != null) {
                                    e.printStackTrace();
                                } else {
                                    System.out.println("Message sent, offset: " + recordMetadata.offset());
                                }
                            }
                        });

                        // Reset the StringBuilder for the next set of data
                        jsonBuilder.setLength(0);
                    }
                } else {
                    String[] parts = line.split(":");
                    if (parts.length == 2) {
                        jsonBuilder.append(String.format("\"%s\":\"%s\",", parts[0].trim().replaceAll(" ", ""), parts[1].trim()));
                    }
                }
            }

            // Send any remaining data in case the last block doesn't end with an empty line
            if (jsonBuilder.length() > 0) {
                String key = "SensorKey";
                long sendTime = System.currentTimeMillis();
                String recordData = jsonBuilder.toString() + String.format("\"sendTime\":%d", sendTime);

                ProducerRecord<String, String> record = new ProducerRecord<>("SensorTopic", key, recordData);
                producer.send(record, new Callback() {
                    @Override
                    public void onCompletion(RecordMetadata recordMetadata, Exception e) {
                        if (e != null) {
                            e.printStackTrace();
                        } else {
                            System.out.println("Message sent, offset: " + recordMetadata.offset());
                        }
                    }
                });
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Operation completed successfully");
    }
}
